Eya & Rayhan's Adventure - Android project
Package: com.eya.rayhan.adventure   Tools: Android Gradle Plugin 8.5.2, Gradle 8.7, JDK 17, compileSdk/targetSdk 34, minSdk 21
The game is app/src/main/assets/index.html (unchanged). No permissions, no ads, works offline.
Build on a phone: see build-apk.yml (GitHub Actions). Build on a computer: open this folder in Android Studio > Build > Build APK(s).
